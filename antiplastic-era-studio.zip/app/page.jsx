'use client';
import { useState, useRef, useEffect } from 'react';

export default function Page() {
  const [keySaved, setKeySaved] = useState(false);
  const [accessKey, setAccessKey] = useState('');
  const [prompt, setPrompt] = useState('golden hour lookbook, editorial, luxury lighting');
  const [messages, setMessages] = useState([]);
  const [imageUrl, setImageUrl] = useState(null);
  const fileRef = useRef(null);

  useEffect(() => {
    const k = localStorage.getItem('APE_KEY');
    if (k) { setAccessKey(k); setKeySaved(true); }
  }, []);

  const addMsg = (m) => setMessages(prev => [...prev, m]);

  const saveKey = () => {
    if (!accessKey.trim()) return;
    localStorage.setItem('APE_KEY', accessKey.trim());
    setKeySaved(true);
    alert('Access key saved.');
  };

  const doGenerate = async () => {
    if (!keySaved) { alert('Enter access key first'); return; }
    addMsg('🎨 Generating...');
    setImageUrl(null);
    try {
      const r = await fetch('/api/replicate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Access-Key': accessKey },
        body: JSON.stringify({ prompt, aspect_ratio: '1:1', size: '2K' })
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Failed');
      setImageUrl(data.imageUrl);
      addMsg('✨ Image ready.');
    } catch (e) {
      addMsg('❌ ' + (e.message || 'Error'));
    }
  };

  const handleFile = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.src = reader.result;
      img.style.borderRadius = '12px';
      const box = document.getElementById('preview');
      if (box) { box.innerHTML = ''; box.appendChild(img); }
    };
    reader.readAsDataURL(f);
  };

  return (
    <div style={{ maxWidth: 980, margin: '24px auto', padding: 16 }}>
      <div style={{ background:'#4a3728', color:'#f5f1ed', padding:'14px 16px', borderRadius:16, display:'flex', gap:8, alignItems:'center', marginBottom:14 }}>
        <div style={{ fontWeight:600, fontFamily:'serif' }}>Antiplastic Era — Seedream</div>
        <input value={accessKey} onChange={e=>setAccessKey(e.target.value)} placeholder="Enter access key" style={{ flex:1, padding:10, border:'2px solid #e8e0d5', borderRadius:12, background:'#f5f1ed', color:'#4a3728' }} />
        <button onClick={saveKey} style={{ background:'#f5f1ed', color:'#4a3728', border:0, borderRadius:12, padding:'10px 14px', cursor:'pointer' }}>Unlock</button>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:14 }}>
        <div style={{ background:'#fff', borderRadius:16, boxShadow:'0 10px 25px rgba(0,0,0,.06)', padding:16 }}>
          <div style={{ fontWeight:600, color:'#4a3728', marginBottom:8 }}>Generate</div>
          <div id="messages" style={{ marginBottom:8 }}>
            {messages.map((m,i)=>(<div key={i} style={{ display:'inline-block', background:'#e8e0d5', color:'#4a3728', borderRadius:12, padding:'8px 10px', margin:'6px 0' }}>{m}</div>))}
          </div>
          <div style={{ display:'flex', gap:8, marginTop:8 }}>
            <input value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="your scene..." style={{ flex:1, padding:10, border:'2px solid #e8e0d5', borderRadius:12 }} />
            <button onClick={doGenerate} style={{ background:'#4a3728', color:'#f5f1ed', border:0, borderRadius:12, padding:'10px 14px', cursor:'pointer' }}>Generate</button>
          </div>
          <div style={{ marginTop:10 }}>
            <input type="file" ref={fileRef} onChange={handleFile} accept="image/*" />
            <span style={{ opacity:.65, fontSize:12 }}> (preview only)</span>
          </div>
          <div id="preview" style={{ marginTop:8 }}></div>
        </div>

        <div style={{ background:'#fff', borderRadius:16, boxShadow:'0 10px 25px rgba(0,0,0,.06)', padding:16 }}>
          <div style={{ fontWeight:600, color:'#4a3728', marginBottom:8 }}>Gallery</div>
          {imageUrl ? <img src={imageUrl} style={{ width:'100%', borderRadius:12 }} /> : <div style={{ opacity:.65, fontSize:12 }}>No images yet</div>}
        </div>
      </div>
    </div>
  );
}
