export const runtime = 'edge';

export async function POST(req: Request) {
  const accessKey = req.headers.get('x-access-key') || '';
  const requiredKey = process.env.ACCESS_CODE || '';
  if (requiredKey && accessKey !== requiredKey) {
    return new Response(JSON.stringify({ error: 'Invalid or missing access key.' }), { status: 401, headers: { 'content-type': 'application/json' } });
  }
  try {
    const body = await req.json();
    const { prompt, aspect_ratio = '1:1', size = '2K' } = body || {};
    const r = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.REPLICATE_API_TOKEN}`,
        'Content-Type': 'application/json',
        Prefer: 'wait'
      },
      body: JSON.stringify({
        version: process.env.REPLICATE_MODEL_VERSION,
        input: {
          prompt: `${prompt}. Ultra realistic, high-end photography, professional lighting, luxury aesthetic, 4K quality, editorial magazine style`,
          negative_prompt: 'low quality, blurry, distorted, plastic, fake, unrealistic, amateur, bad lighting',
          aspect_ratio,
          size
        }
      })
    });
    const data = await r.json();
    if (!r.ok) return new Response(JSON.stringify({ error: data?.detail || 'Replicate failed' }), { status: 500, headers: { 'content-type': 'application/json' } });
    const out = Array.isArray(data.output) ? data.output[0] : data.output;
    return new Response(JSON.stringify({ imageUrl: out ?? null }), { headers: { 'content-type': 'application/json' } });
  } catch (e:any) {
    return new Response(JSON.stringify({ error: e.message || 'Server error' }), { status: 500, headers: { 'content-type': 'application/json' } });
  }
}
