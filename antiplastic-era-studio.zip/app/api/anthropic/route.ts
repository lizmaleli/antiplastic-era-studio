export const runtime = 'edge';

export async function POST(req: Request) {
  const accessKey = req.headers.get('x-access-key') || '';
  const requiredKey = process.env.ACCESS_CODE || '';
  if (requiredKey && accessKey !== requiredKey) {
    return new Response(JSON.stringify({ error: 'Invalid or missing access key.' }), { status: 401, headers: { 'content-type': 'application/json' } });
  }
  try {
    const body = await req.json();
    const { messages, system, max_tokens = 120 } = body || {};
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': process.env.ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens,
        system,
        messages
      })
    });
    const data = await r.json();
    if (!r.ok) return new Response(JSON.stringify({ error: data?.error?.message || 'Anthropic failed' }), { status: 500, headers: { 'content-type': 'application/json' } });
    const text = data?.content?.[0]?.text ?? '';
    return new Response(JSON.stringify({ text }), { headers: { 'content-type': 'application/json' } });
  } catch (e:any) {
    return new Response(JSON.stringify({ error: e.message || 'Server error' }), { status: 500, headers: { 'content-type': 'application/json' } });
  }
}
