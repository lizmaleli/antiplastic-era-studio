export const metadata = { title: "Antiplastic Era Studio" };
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ background: "linear-gradient(135deg,#f5f1ed 0%,#e8e0d5 100%)", margin: 0 }}>{children}</body>
    </html>
  );
}