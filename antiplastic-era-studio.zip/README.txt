Antiplastic Era Studio — Next.js

Deploy:
1) Create a new GitHub repo and upload this folder.
2) In Vercel → New Project → Import the repo.
3) Add Environment Variables:
   - REPLICATE_API_TOKEN = r8_...
   - REPLICATE_MODEL_VERSION = <Seedream version id from Replicate>
   - ANTHROPIC_API_KEY = sk-ant-... (optional)
   - ACCESS_CODE = GOLD-111 (optional; leave blank to disable gating)
4) Deploy, copy your URL (https://...vercel.app)
5) Payhip → Custom Page → Add HTML:
   <iframe src="YOUR_URL" style="width:100%;height:1100px;border:0;border-radius:16px;overflow:hidden"></iframe>
